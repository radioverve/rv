<?php
include ("wpemn_config.php");
$dbh = mysql_connect("$dbhost", "$dbuser", "$dbpass");
mysql_select_db("$db", $dbh);
?>

<html>
<head>
<title>WordPress Email Notification Plugin v2.3.1 Upgrade</title>

<style type="text/css">

body {
	background: #93B4D7;
	text-align: center;
	font-family: "Trebuchet MS", "Bitstream Vera Sans", verdana, lucida, arial, helvetica, sans-serif;
	font-size: 12px;
}

 #wrap {
 	border: 1px solid #000000;
  width: 600px;
  min-height: 400px;
	text-align: left;	
	margin: 10px auto 10px;
	padding: 0;	
	background: #FFFFCC;
	}

h1 {
	font-size: 18px;
	border-bottom: 1px solid #000000;
	padding-left: 10px;
	}

h2 {
	font-size: 16px;
	padding-left: 10px;
	}

p {
	padding-left: 10px;	
	}

</style>

</head>
<body>

<div id="wrap">

<h1>WordPress Email Notification Plugin v2.3.1 Upgrade</h1>

<?php
if (isset($_GET['step']))
	$step = $_GET['step'];
else
	$step = 0;

switch($step) {

	case 0:
?>

<form id="setup" method="post" action="upgrade.php?step=1">

<table width="100%">
<tr>
	<th>Default Notification Value:</th>
	<td>
        <select name="default_send" id="default_send" />
          <option>No</option>
          <option>Yes</option>
        </select>	
	</td>
</tr>

<tr>
	<td></td>
	<td>
		<input type="submit" name="Submit" value="Install &raquo;" />
		<br /><br />
	</td>
</tr>

</table>
</form>


<?php
	break;

	case 1:
?>

<p>

<?php

# Add field to table
$alter_sql  = "ALTER TABLE wp_email_list_config ";
$alter_sql .= "ADD default_send VARCHAR( 3 ) default NULL ";
       
echo "Updating table: wp_email_list_config ...<br />";
mysql_query( $alter_sql );

# Update Default Send
$update = " UPDATE wp_email_list_config ";
$update .= "SET ";
$update .= "default_send = '$default_send' ";
$update .= "WHERE id = '1'";

mysql_query( $update );

# Add new table
$add_sql = "CREATE TABLE wp_email_list_future (
				post_ID bigint(20) NOT NULL default '0',
				post_date char(12) NOT NULL default '0',
				notification_sent char(1) NOT NULL default '',
				PRIMARY KEY  (post_ID)
       )"; 
       
echo "Creating table: wp_email_list_future ...<br />";
mysql_query( $add_sql );
?>
</p>

<p>
<em>Finished!</em>
<br /><br />
You should now remove upgrade.php from your server.
</p>

<?php
	break;
}
?>
</div>