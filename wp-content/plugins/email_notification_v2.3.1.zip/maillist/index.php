<?php
#------------------------------------------------------#
# INFO                                                 #
#------------------------------------------------------#
# Title: E-Mail Notification                           #
# Author: Brian Groce (http://watershedstudio.com)     #
# Date: December 8, 2005                               #
# Version: 2.3.1                                       #
#                                                      #
# Credits & Changelog: see readme.txt                  #
#------------------------------------------------------#

include ("wpemn_config.php");

//********************************************************//
//                  GET VARIABLES FROM URL
//********************************************************//
$action=$_GET['action'];
$id=$_GET['id'];
$addr=$_GET['addr'];

//********************************************************//
//                    DB CONNECTION
//********************************************************//
$dbh = mysql_connect("$dbhost", "$dbuser", "$dbpass");
mysql_select_db("$db", $dbh);

if ($_POST['email']) {
    $action = 'sub';
    $addr = $_POST['email'];
}

//********************************************************//
//                    GET CONFIG INFO
//********************************************************//
$query = "select * from wp_email_list_config where id = '1'";
$res = mysql_query($query) or print mysql_error();
$row = mysql_fetch_assoc($res);

$site_name = $row['site_name'];
$site_url = $row['site_url'];
$blog_url = $row['blog_url'];
$from_email = $row['from_email'];
$admin_email = $row['admin_email'];
$nice_urls = $row['nice_urls'];
?>

<div id="content"><br /><br /><br />
<?php

if ($action == "") { echo "Sorry, no action was supplied."; exit; }

//********************************************************//
//                      SUBSCRIBE
//********************************************************//
if ($action == "sub") {
    $query = "select id,email_addr,gets_mail from wp_email_list where email_addr = '$addr'";
    $res = mysql_query($query) or print mysql_error();

    $row = mysql_fetch_assoc($res);

    if ($row['email_addr'] == $addr && $row['gets_mail'] == 1) {
        echo "You're already subscribed! :)<br><br><a href=$blog_url>Go Back</a>";
        exit;
    }

    if ($row['email_addr'] != $addr) {
        $query = "insert into wp_email_list (email_addr,date_subscribed) values ('$addr',now())";
        $res = mysql_query($query) or print mysql_error();
        $id = mysql_insert_id();
    } else {
        $id = $row['id'];
    }

    send_conf($addr,$id,"0",$site_url,$blog_url,$site_name,$from_email);

    echo "Thanks for subscribing. <br>You will receive an email shortly to confirm ";
		echo "your subscription. <br>Once you confirm your subscription you will begin to receive ";
		echo "<br>notifications whenever $site_name is updated.<br><br><a href=$blog_url>Go Back</a>";

    }

//********************************************************//
//                       INVITE
//********************************************************//

elseif ($action == "inv") {
    $query = "select id,email_addr,gets_mail from wp_email_list where email_addr = '$addr'";
    $res = mysql_query($query) or print mysql_error();

    $row = mysql_fetch_assoc($res);

    if ($row['email_addr'] == $addr && $row['gets_mail'] == 1) {
        echo "$addr is already subscribed! :)<br><br><a href=$blog_url>Go Back</a>";
        exit;
    }

    if ($row['email_addr'] != $addr) {
        $query = "insert into wp_email_list (email_addr,date_subscribed) values ('$addr',now())";
        $res = mysql_query($query) or print mysql_error();
        $id = mysql_insert_id();
    } else {
        $id = $row['id'];
    }

    send_conf($addr,$id,"invite",$site_url,$blog_url,$site_name,$from_email);

    echo "$addr has been sent an invitation to subscribe.<br /><br/><a href=$blog_url>Go Back</a>";

    }

//********************************************************//
//                    UNSUBSCRIBE
//********************************************************//
    elseif ($action == "unsub") {

    $query = "delete from wp_email_list where email_addr = '$addr'";
    $res = mysql_query($query) or print mysql_error();
    if (mysql_affected_rows() > 0) {

			$msg =  "$addr has unsubscribed.\n";

			$header = "From: \"$site_name\" <$from_email>\n";

			Mail($admin_email, "$site_name Unsubscribe: $addr", $msg, $header);

			$msg =  "$addr will no longer receive notifications from $site_name.\n\n";
			$msg .= "If you would like to sign up again, visit: $blog_url\n\n";
			$msg .= "Thanks,\n\n$site_name";

			$header = "From: \"$site_name\" <$from_email>\n";

			Mail($addr, "$site_name Unsubscribe", $msg, $header);
    }
    echo "You will no longer receive notifications from $site_name.<br><br><a href=$blog_url>Go Back</a>";
}

//********************************************************//
//                      CONFIRM
//********************************************************//

elseif ($action == "conf") {
    list($id,$md) = explode(',',$addr);
    $query = "select email_addr from wp_email_list where id = $id";
    $res = mysql_query($query);
    $row = mysql_fetch_assoc($res);
    $addr2 = $row['email_addr'];

    if (md5($addr2) == $md) {
        $query = "update wp_email_list set gets_mail = 1 where id = $id";
        $res = mysql_query($query);

			$msg =  "$addr2 has subscribed.\n";

			$header = "From: \"$site_name\" <$from_email>\n";
			$header .= "Sender: $from_email\n";

			Mail($admin_email, "$site_name Subscribe: $addr2", $msg, $header);

      echo "Thanks for confirming your subscription, $addr2.<br>";
      echo "You will now receive email notifications whenever<br>";
      echo "$site_name is updated.<br><br>";
      echo "<a href=$blog_url>Go Back</a>";

    } else {
        echo "I'm sorry, that address is not in our database.<br>";
        echo "Please try subscribing again.<br><br>";
        echo "<a href=$blog_url>Go Back</a>";
    }
}

//********************************************************//
//                        EMPTY
//********************************************************//

else {
    echo "Sorry, no action was supplied.";
}


//********************************************************//
//                 FUNCTION - send_conf
//********************************************************//

function send_conf($addr,$id,$invite,$site_url,$blog_url,$site_name,$from_email) {

    // This is for the default URL permalink
		$confurl = $site_url . "maillist/index.php?action=conf&addr=$id," . md5($addr);

    if ($invite == 'invite') {

			$msg =  "Someone has invited you to receive e-mail\n";
			$msg .= "notifications from $site_name. If you would\n";
			$msg .= "like to receive these notifications, please visit the URL below\n";
			$msg .= "to confirm. Thanks!\n\n";
			$msg .= "$confurl\n\n";
			$msg .= "If you are not interested, you can safely\n";
			$msg .= "disregard this message.\n";

			$header = "From: \"$site_name\" <$from_email>\n";
			$header .= "Sender: $from_email\n";

			Mail($addr, "$site_name Invitation", $msg, $header);

    } else {

			$msg =  "Someone has requested that $addr be subscribed to receive\n";
			$msg .= "notifications from $site_name. If this was you, please\n";
			$msg .= "visit the URL below to confirm your subscription. Thanks!\n\n";
			$msg .= "$confurl\n\n";
			$msg .= "If you did not ask to be subscribed to the list, you can safely\n";
			$msg .= "disregard this message. We apologize for your trouble.\n";

			$header = "From: \"$site_name\" <$from_email>\n";
			$header .= "Sender: $from_email\n";

			Mail($addr, "$site_name Confirmation", $msg, $header);

    }
}

?>
</div>