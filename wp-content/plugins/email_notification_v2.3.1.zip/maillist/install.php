<?php  import_request_variables(gp, "");  ?>

<html>
<head>
<title>WordPress Email Notification Plugin v2.3.1 Install</title>

<style type="text/css">

body {
	background: #93B4D7;
	text-align: center;
	font-family: "Trebuchet MS", "Bitstream Vera Sans", verdana, lucida, arial, helvetica, sans-serif;
	font-size: 12px;
}

 #wrap {
 	border: 1px solid #000000;
  width: 600px;
  min-height: 400px;
	text-align: left;	
	margin: 10px auto 10px;
	padding: 0;	
	background: #FFFFCC;
	}

h1 {
	font-size: 18px;
	border-bottom: 1px solid #000000;
	padding-left: 10px;
	}

h2 {
	font-size: 16px;
	padding-left: 10px;
	}

p {
	padding-left: 10px;	
	}

</style>

</head>
<body>

<div id="wrap">

<h1>WordPress Email Notification Plugin v2.3.1 Install</h1>

<?php
if (isset($_GET['step']))
	$step = $_GET['step'];
else
	$step = 0;

switch($step) {

	case 0:
?>

<h2><a href="install.php?step=1">Install WordPress Email Notification Plugin v2.3.1 &raquo;</a></h2>
</div>
<?php
	break;

	case 1:
?>
<h2>Site Information</h2>

<form id="setup" method="post" action="install.php?step=2">

<table width="100%">
<tr>
<th width="33%">Database Name:</th>
<td><input name="db" type="text" id="db" size="35" /></td>
</tr>

<tr>
	<th>Database User:</th>
	<td><input name="dbuser" type="text" id="dbuser" size="35" /></td>
</tr>

<tr>
	<th>Database Password:</th>
	<td><input name="dbpass" type="password" id="dbpass" size="35" /></td>
</tr>

<tr>
	<th>Database Host:</th>
	<td><input name="dbhost" type="text" id="dbhost" size="35" value="localhost" /></td>
</tr>


<tr>
	<th>Site Name:</th>
	<td><input name="site_name" type="text" id="site_name" size="35" /></td>
</tr>


<tr>
	<th>Site URL:</th>
	<td><input name="site_url" type="text" id="site_url" size="35" value="http://<?php echo "$HTTP_HOST"; ?>/" /></td>
</tr>


<tr>
	<th>Blog URL:</th>
	<td><input name="blog_url" type="text" id="blog_url" size="35" value="http://<?php echo "$HTTP_HOST"; ?>/" /></td>
</tr>

<tr>
	<th>From E-mail Address:</th>
	<td><input name="from_email" type="text" id="from_email" size="35" /></td>
</tr>


<tr>
	<th>Admin Email Address:</th>
	<td><input name="admin_email" type="text" id="admin_email" size="35" /></td>
</tr>

<tr>
	<th>Nice URL's:</th>
	<td>
        <select name="nice_urls" id="nice_urls" />
          <option>No</option>
          <option>Yes</option>
        </select>	
	</td>
</tr>

<tr>
	<th>Show Full Post In Email:</th>
	<td>
        <select name="show_content" id="show_content" />
          <option>No</option>
          <option>Yes</option>
        </select>	
	</td>
</tr>


<tr>
	<th>Send HTML Email:</th>
	<td>
        <select name="html_email" id="html_email" />
          <option>No</option>
          <option>Yes</option>
        </select>	
	</td>
</tr>


<tr>
	<th>Default Notification Value:</th>
	<td>
        <select name="default_send" id="default_send" />
          <option>No</option>
          <option>Yes</option>
        </select>	
	</td>
</tr>

<tr>
	<td></td>
	<td>
		<input type="submit" name="Submit" value="Install &raquo;" />
		<br /><br />
	</td>
</tr>

</table>


</form>
</div>

<?php
	break;
	case 2:
?>
<h2>Installing</h2>

<p>
<?php

$data = "<?
//********************************************************//
//               MAILLIST SETTINGS
//********************************************************//

# CONFIG SECTION

  # Database Information
  " . '$db' . "     = '$db';
  " . '$dbuser' . " = '$dbuser';
  " . '$dbpass' . " = '$dbpass';
  " . '$dbhost' . " = '$dbhost'; // localhost is default

# END CONFIG SECTION
?>";  

$file = "wpemn_config.php";   
if (!$file_handle = fopen($file,"w")) { echo "Cannot open file"; }  
if (!fwrite($file_handle, $data)) { echo "Cannot write to file"; }  
echo "You have successfully written data to $file <br />";   
fclose($file_handle);  

//** Do the DB stuff **//
$dbh = mysql_connect("$dbhost", "$dbuser", "$dbpass");
mysql_select_db("$db", $dbh);

//****************************************//
//**  Create wp_email_list table        **// 
//****************************************//

$sql = "CREATE TABLE wp_email_list (
			  id int( 11 ) NOT NULL auto_increment,
			  email_addr varchar( 255 ) default NULL,
			  gets_mail int( 11 ) default NULL,
			  last_modified timestamp( 14 ) NOT NULL,
			  date_subscribed datetime default NULL,
			  PRIMARY KEY  ( id )   
       )";
       
echo "Creating table: wp_email_list...<br />";
mysql_query( $sql );

//****************************************//
//**  Create wp_email_list_config table **// 
//****************************************//

$sql = "DROP TABLE IF EXISTS wp_email_list_config";
mysql_query( $sql );
   
$sql = "CREATE TABLE wp_email_list_config (
			  id int( 11 ) NOT NULL auto_increment,
			  site_name varchar( 255 ) default NULL,
			  site_url varchar( 255 ) default NULL,
			  blog_url varchar( 255 ) default NULL,			  
			  from_email varchar( 255 ) default NULL,
			  admin_email varchar( 255 ) default NULL,
			  nice_urls varchar( 3 ) default NULL,
			  show_content varchar( 3 ) default NULL,
			  html_email varchar( 3 ) default NULL,
			  default_send VARCHAR( 3 ) NOT NULL,
			  PRIMARY KEY  ( id )   
       )";
       
echo "Creating table: wp_email_list_config...<br />";
mysql_query( $sql );

//*****************************************//
//** Populate wp_email_list_config table **// 
//*****************************************//

$sql = "INSERT INTO wp_email_list_config (site_name, site_url, blog_url, from_email, admin_email, nice_urls, show_content, html_email, default_send) 
				VALUES ('$site_name', '$site_url', '$blog_url', '$from_email', '$admin_email', '$nice_urls', '$show_content', '$html_email', '$default_send')
				";
       
echo "Populating table: wp_email_list_config...<br />";
mysql_query( $sql );

# Add new table
$add_sql = "CREATE TABLE wp_email_list_future (
				post_ID bigint(20) NOT NULL default '0',
				post_date char(12) NOT NULL default '0',
				notification_sent char(1) NOT NULL default '',
				PRIMARY KEY  (post_ID)
       )"; 
       
echo "Creating table: wp_email_list_future ...<br />";
mysql_query( $add_sql );
?>

</p>
<p>
<em>Finished!</em>
<br /><br />
You should now remove install.php from your server.
</p>
</div>
<?php
	break;
}
?>


</body>
</html>