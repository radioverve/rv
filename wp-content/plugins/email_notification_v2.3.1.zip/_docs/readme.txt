#----------------------------------------------------------#
# INFO                                                     #
#----------------------------------------------------------#
# Title: E-Mail Notification                               #
# Author: Brian Groce (http://briangroce.com)              #
# Date: December 8, 2005                                   #
# Version: 2.3.1                                           #
#                                                          #
# Note: This was created for and tested in WordPress v1.5  #
#----------------------------------------------------------#



#----------------------------------------------------------#
# CREDITS                                                  #
#----------------------------------------------------------#
# BASED ON                                                 #
#----------------------------------------------------------#
# Email notification for WordPress.                        #
# Jon Anhold <jon@imagesafari.com> 11/2003                 #
# Please keep this attribution in place.                   #
#                                                          #
#----------------------------------------------------------#
# PLUGIN BY                                                #
#----------------------------------------------------------#
# Brian Groce :: watershedstudio.com :: briangroce.com     #
#----------------------------------------------------------#


#----------------------------------------------------------#
# CHANGELOG                                                #
#----------------------------------------------------------#

http://watershedstudio.com/portfolio/software/wp-email-notification.html#changelog